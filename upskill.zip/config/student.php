<?php
return [
    "dashboard" => env("STUDENT_DASHBOARD", "student/dashboard"),
];
