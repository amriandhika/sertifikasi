<?php
namespace App\Supports;
use Jenssegers\Date\Date;

class DateSupport extends Date
{
}
